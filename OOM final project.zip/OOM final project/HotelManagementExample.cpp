//#include"Customer.h"
//#include"Room.h"
//#include"LuxuriousRoom.h"
//#include"Hotel.h"
#include"Hotel.h"
//#include<iostream>
#include<string>
#include<ncurses.h>
#include<stdlib.h>

using std::cin;
using std::cout;
using std::string;
using namespace example;


void manage()
{
    Hotel hotel("Taj Hotel","1234");
    int opt1;
    do
    {
    system("clear");
    cout<<"\n-------"<<hotel.hotel_name<<"-------";
    cout<<"\n1.) Staff";
    cout<<"\n2.) Customer";
    cout<<"\n3.) Exit";
    cout<<"\n Enter option: ";
    cin>>opt1;
    switch(opt1)
    {
        case 1:
        {
          cout<<"\n Enter password: ";
          string pass; cin>>pass;
          if(pass==hotel.get_hotel_password())
          {
            int opt2;
            do
            {
              system("clear");
              cout<<"\n1.) Add Room";
              cout<<"\n2.) Search Customer";
              cout<<"\n3.) Search Room";
              cout<<"\n4.) Get present guest summary";
              cout<<"\n5.) Get all records";
              cout<<"\n6.) Exit";
              cout<<"\n Enter option: ";
              cin>>opt2;

              switch(opt2)
              {
                case 1:
                {
                system("clear");
                cout<<"\n Normal Room/Luxurious Room[N/L]: ";
                char ans; cin>>ans;
                if(ans=='N')
                {
                  Room room;
                  room.set_room_details();
                  hotel.addRoom(room);
                }
                else if(ans=='L')
                {
                  LuxuriousRoom room;
                  room.set_room_details();
                  hotel.addRoom(room);
                }
                else
                {
                  cout<<"\n You entered a wrong option.";
                }
                getch();
                break;
                }

                case 2:
                system("clear");
                hotel.searchCustomer();
                getch();
                break;

                case 3:
                {
                system("clear");
                int room_no;
                cout<<"\n Enter Room Number: ";
                cin>>room_no;
                hotel.searchRoom(room_no);
                getch();
                break;
                }

                case 4:
                system("clear");
                hotel.getGuestSummary();
                getch();
                break;

                case 5:
                system("clear");
                hotel.viewRecord();
                cout<<"\n Thank You \n";
                getch();
                break;

                case 6:
                break;

                default:
                cout<<"\n Wrong option";
                getch();
              }
        
            }while(opt2!=6);
          }
          else
          {
            cout<<"\n Wrong Password ";
            getch();
          }
          break;
        }

        case 2:
        {
        int opt3;
        do
        {
         system("clear");
         cout<<"\n1.) Check In ";
         cout<<"\n2.) Check out ";
         cout<<"\n3.) Check available rooms";
         cout<<"\n4.) Exit ";
         cout<<"\n Enter option: ";
         cin>>opt3;
        
         switch(opt3)
         {
            case 1:
            system("clear");
            hotel.checkIn();
            getch();
            break;

            case 2:
            system("clear");
            hotel.checkOut();
            getch();
            break;
            
            case 3:
            system("clear");
            hotel.check_available_rooms();
            getch();
            break;

            case 4:
            break;
            
            default:
            cout<<"\n Wrong Option.";
            getch();
         }  
        }while(opt3!=4);
        }

        case 3:
        cout<<"\n Thank You";
        break;

        default:
        cout<<"\n Wrong option";

    }
} while (opt1!=3);

    
}

int main(void)
{
  manage();
  return 0;
}
// g++ Customer.cpp Room.cpp LuxuriousRoom.cpp Hotel.cpp HotelManagementExample.cpp -lncurses
