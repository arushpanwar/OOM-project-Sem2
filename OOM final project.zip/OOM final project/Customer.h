#ifndef __CUSTOMER
#define __CUSTOMER

#include<string>
using std::string;

namespace example
{
    
class Customer
{
    private:
    string name;
    string phone;
    string check_in_date;
    string check_out_date;
    int days;
    int hotel_id;
    int id_proof;
    static int hotel_id_counter;

    public:
    Customer();
    void fill_customer_details();
    string get_name();
    string get_phone();
    string get_check_in_date();
    string get_check_out_date();
    int get_hotel_id();
    int get_days();
    void displayCustomerDetails();
};

}

#endif